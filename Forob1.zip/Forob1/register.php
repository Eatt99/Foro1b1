<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Registro</h2>
        <form action="register.php" method="POST">
            <label for="username">Usuario:</label>
            <input type="text" name="username" required>
            <label for="email">Correo electrónico:</label>
            <input type="email" name="email" required>
            <label for="password">Contraseña:</label>
            <input type="password" name="password" required>
            <button type="submit">Registrar</button>
        </form>
        <p>¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a></p>
    </div>
</body>
</html>

<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Preparar consulta SQL
    $stmt = $mysqli->prepare("INSERT INTO sistema_autenticacion (username, email, password) VALUES (?, ?, ?)");

    if ($stmt === false) {
        die('Error al preparar la consulta: ' . $mysqli->error);
    }

    // Enlazar parámetros (s = string)
    $stmt->bind_param("sss", $username, $email, $password);

    try {
        $stmt->execute();
        $stmt->close();
        header("Location: respuesta.php?username=" . urlencode($username));
        exit();
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}



?>
