<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro exitoso</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <?php
        if (isset($_GET['username'])) {
            $username = htmlspecialchars($_GET['username']);
            echo "<h2>¡Hola, $username!</h2>";
            echo "<p>Te has registrado exitosamente en nuestro sistema.</p>";
        }
        ?>
        <p><a href="login.php">Inicia sesión</a> para continuar.</p>
    </div>
</body>
</html>

